# PHT Cluod PC — website mẫu

## Có gì trong bộ này?
- Trang giới thiệu Cloud PC, bảng giá ngày/tuần/tháng.
- Giao diện responsive cho điện thoại và máy tính.
- Nút đăng nhập dạng giao diện mẫu.

## Lưu ý quan trọng
Đăng nhập hiện **chưa hoạt động như hệ thống tài khoản thật**. Không nhập mật khẩu thật vào bản mẫu này. Muốn có đăng ký/đăng nhập an toàn cần tạo backend hoặc kết nối dịch vụ xác thực (ví dụ Firebase Authentication) và cấu hình riêng.

## Đưa website lên GitHub Pages
1. Tạo repository công khai tên `pht-cloud-pc` trên GitHub.
2. Tải lên 3 tệp `index.html`, `style.css`, `script.js` cùng `README.md` ở thư mục gốc.
3. Vào **Settings → Pages**.
4. Ở **Build and deployment**, chọn **Deploy from a branch**.
5. Chọn branch **main**, folder **/(root)** rồi bấm **Save**.
6. Đợi GitHub tạo địa chỉ Pages trong mục Pages.

Không chia sẻ mật khẩu GitHub cho bất kỳ ai. Chỉ công khai thông tin dịch vụ cần thiết.
